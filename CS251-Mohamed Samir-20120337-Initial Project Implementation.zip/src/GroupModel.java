public class GroupModel {

    public Group myGroup;

  public void createGroup() {
  }

  public void updateGroup() {
  }

  public void getGroup() {
  }

  public void deleteGroup() {
  }

}