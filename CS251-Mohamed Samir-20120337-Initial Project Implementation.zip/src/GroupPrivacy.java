public abstract class GroupPrivacy {

//  public List<IUser> allowedUsers;

    public IGroup myIGroup;

  public void getAllowedMembers(IGroup group) {
  }

}