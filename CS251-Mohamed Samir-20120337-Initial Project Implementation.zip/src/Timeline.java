import java.util.Vector;

public abstract class Timeline {

    public Vector  hasA;

  public void getPosts() {
  }

}