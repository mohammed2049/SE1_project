public class ClosedPrivacy extends GroupPrivacy {

  
  public void isAllowed(IUser user) {
  }

}