public class Group extends IGroup {

  public String title;

  public String coverPicture;

//  public users:Map<IUser,Role>;

    public GroupModel myGroupModel;

  public void addMember(IUser user) {
  }

  public void removeMember() {
  }

  public void setRole() {
  }

}