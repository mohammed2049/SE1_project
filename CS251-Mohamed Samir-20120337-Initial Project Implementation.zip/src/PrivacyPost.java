public abstract class PrivacyPost extends Post {

  public Post myPost;

  public void writePost() {
  }

  public void setAllowedMembers() {
  }

  public void PrivacyPost(Post p) {
  }

}