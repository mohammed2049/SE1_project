public class ChatMessage extends Message {

  public IUser receiver;

  public void addReceiver() {
  }

}