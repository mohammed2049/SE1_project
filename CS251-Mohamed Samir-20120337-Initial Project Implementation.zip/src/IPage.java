import java.util.Vector;

public abstract class IPage {

    public Vector  myIUser;
    /**
   * 
   * @element-type IUser
   */
  public Vector  like;

  public void likeAPage() {
  }

}