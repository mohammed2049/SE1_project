public class ProfileTimeline extends Timeline {

  public void getPosts() {
  }

}