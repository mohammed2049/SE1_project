public class UserModel {

    

  static public boolean CreateUser(IUser user) {
	  System.out.print(user.email + "\n" + user.gender+ "\n" + user.name+"\n" + user.password+"\n"+ user.type);
	  return true;
  }

  public void DeleteUser() {
  }

  public void getUser() {
  }

  public void updateUser() {
  }

  static public boolean addFriendRequest(String e1,String e2){
	  System.out.println( e1 +"  "+ e2  );
	  return true;
  }
}