public class PagePost extends Post {

  public void writePost() {
  }

}