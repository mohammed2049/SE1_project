import java.util.Vector;

public abstract class Message {

    public Vector  myIUser;

  public void sendMessage() {
  }

  public void addReceiver() {
  }

}