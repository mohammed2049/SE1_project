public class PageModel {

    public Page myPage;

  public void createPage() {
  }

  public void deletePage() {
  }

  public void getPage() {
  }

  public void updatePage() {
  }

}