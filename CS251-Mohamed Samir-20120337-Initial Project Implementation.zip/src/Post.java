import java.util.Vector;

public abstract class Post {

//  public List<IUser> currentAllowed;
//
//    public Vector  hasA;
//    public Vector  hasA;

  public void writePost() {
  }

}