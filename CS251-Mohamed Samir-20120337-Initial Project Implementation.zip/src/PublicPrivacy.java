public class PublicPrivacy extends GroupPrivacy {

  public Integer importance;

  public void setImportance() {
  }

  public void getImportance() {
  }

}