public class PublicPost extends PrivacyPost {

  public void setAllowedMembers() {
  }

}