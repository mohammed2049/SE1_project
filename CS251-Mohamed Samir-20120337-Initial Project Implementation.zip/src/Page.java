import java.util.Vector;

public class Page extends IPage {

//  public Integer users : List<IUser>;
//
//    public Vector  myIUser;
//    public Vector  myIUser;
//    public PageModel myPageModel;

  public void likeAPage() {
  }

}