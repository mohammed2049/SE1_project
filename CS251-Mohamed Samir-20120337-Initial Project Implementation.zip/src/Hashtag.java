public class Hashtag extends IHashtag {

  public void sort(String text) {
  }

  public void search(String text) {
  }

  public void count(String text) {
  }

}