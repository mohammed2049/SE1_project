public class MessageModel {

  public void createMessage() {
  }

  public void deleteMessage() {
  }

  public void getMessage() {
  }

  public void updateMessage() {
  }

}