public class PrivatePost extends PrivacyPost {

  public void setAllowedMembers() {
  }

}