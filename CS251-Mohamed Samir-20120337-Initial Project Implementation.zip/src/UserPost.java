public class UserPost extends Post {

  public void writePost() {
  }

}