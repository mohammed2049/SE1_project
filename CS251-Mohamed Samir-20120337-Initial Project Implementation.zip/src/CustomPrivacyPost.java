public class CustomPrivacyPost extends PrivacyPost {

  public void setAllowedMembers() {
  }

}