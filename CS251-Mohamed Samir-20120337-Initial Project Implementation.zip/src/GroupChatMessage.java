import java.util.*;

public class GroupChatMessage extends Message {

  public List<IUser> allUsers;

  public String title;

  public void addReceiver() {
	  
  }

}