public class PublicTimeline extends Timeline {

  public void getPosts() {
  }

  public void getPublicGroups() {
  }

}