public class PostModel {

  public void createPost() {
  }

  public void deletePost() {
  }

  public void getPost() {
  }

  public void updatePost() {
  }

}